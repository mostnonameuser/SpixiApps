// --- Глобальные переменные ---
let currentSessionId = null;
let currentUserId = null;
// SERVER_API_URL больше не нужен

// --- Функции SDK Callbacks ---
function onSessionStart(sessionId, userId) {
    console.log('Session started:', sessionId, 'User:', userId);
    currentSessionId = sessionId;
    currentUserId = userId;

    // Загрузка истории из локального хранилища Spixi
    loadChatHistory();
}

function onSessionEnd() {
    console.log('Session ended.');
    currentSessionId = null;
    currentUserId = null;
}

function onMessage(senderId, data) {
    console.log('Received message from', senderId, ':', data);
    // Обработка сообщения от другого участника сессии (например, от "сервера" или бота)
    // Предположим, 'data' - это строка с ответом от LLM
    if (typeof data === 'string' && data.trim() !== '') {
        // Добавляем сообщение от "сервера" в UI
        addMessageToUI(data, 'server');
        // Сохраняем историю, так как пришло новое сообщение
        saveChatHistory();
    } else {
        console.warn('Received non-string or empty message data:', data);
    }
}

function onUserJoined(userId) {
    console.log('User joined:', userId);
    // Добавить логику, если нужно что-то делать при входе другого пользователя.
    // В вашем случае, возможно, не нужно.
}

function onUserLeft(userId) {
    console.log('User left:', userId);
    // Добавить логику, если нужно что-то делать при выходе пользователя.
    // В вашем случае, возможно, не нужно.
}

function onError(error) {
    console.error('SDK Error:', error);
    addMessageToUI('Ошибка: ' + error, 'server');
}

// --- Внутренние функции ---

function loadChatHistory() {
    SpixiAppSDK.storageGet('chatHistory', function (error, result) {
        if (error) {
            console.error('Error loading chat history:', error);
            // Если ошибка или истории нет, начинаем с пустого массива
            return;
        }
        const history = result ? JSON.parse(result) : [];
        history.forEach(msg => {
            addMessageToUI(msg.text, msg.sender);
        });
    });
}

function saveChatHistory() {
    const messages = [];
    const messageElements = document.querySelectorAll('#messages .message');
    messageElements.forEach(el => {
        messages.push({
            text: el.querySelector('.message-text').textContent,
            sender: el.classList.contains('user') ? 'user' : 'server'
        });
    });

    const historyString = JSON.stringify(messages);
    SpixiAppSDK.storageSet('chatHistory', historyString, function (error) {
        if (error) {
            console.error('Error saving chat history:', error);
        } else {
            console.log('Chat history saved.');
        }
    });
}

function addMessageToUI(text, sender) {
    const messagesDiv = document.getElementById('messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    const textSpan = document.createElement('span');
    textSpan.className = 'message-text';
    textSpan.textContent = text;
    messageDiv.appendChild(textSpan);

    messagesDiv.appendChild(messageDiv);
    messagesDiv.scrollTop = messagesDiv.scrollHeight; // Авто-прокрутка вниз
}

function sendMessageToSpixiSession(text) {
    const sendButton = document.getElementById('send-button');
    const input = document.getElementById('message-input');

    // Проверка на пустое сообщение
    if (!text.trim()) {
        return;
    }

    // Отключаем кнопку и поле ввода на время отправки
    sendButton.disabled = true;
    input.disabled = true;

    // Добавляем сообщение пользователя в UI
    addMessageToUI(text, 'user');

    // Отправляем сообщение в сессию Spixi
    // 'text' будет передано как 'data' в колбэк onMessage другим участникам
    SpixiAppSDK.sendMessage(text, function(error) {
        if (error) {
            console.error('Error sending message via Spixi SDK:', error);
            // Опционально: обновить UI, чтобы сообщение пользователя не выглядело "отправленным", если произошла ошибка
            // Но в данном случае, оставим его, как индикатор, что была попытка
            addMessageToUI('Ошибка отправки: ' + error, 'server'); // Показываем ошибку как "серверное" сообщение
        } else {
            console.log('Message sent to session.');
            // Сообщение отправлено, ожидаем ответ через onMessage
        }
        // Включаем кнопку и поле ввода
        sendButton.disabled = false;
        input.disabled = true; // Оставляем поле ввода активным, чтобы пользователь мог ввести следующее сообщение
        input.value = ''; // Очищаем поле ввода после отправки
        saveChatHistory(); // Сохраняем историю после отправки сообщения
    });
}


// --- Обработчики событий DOM ---
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('send-button').addEventListener('click', function() {
        const input = document.getElementById('message-input');
        const messageText = input.value;
        sendMessageToSpixiSession(messageText);
    });

    document.getElementById('message-input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const messageText = e.target.value;
            sendMessageToSpixiSession(messageText);
        }
    });
});
